SELECT COUNT(*) AS ArtistCount FROM Artist
