# Query: last above the artist contributed to the less albums?

## SQL

```sql
SELECT Artist.Name, COUNT(Album.AlbumId) AS AlbumCount FROM Album JOIN Artist ON Album.ArtistId = Artist.ArtistId GROUP BY Artist.Name ORDER BY AlbumCount ASC LIMIT 1 OFFSET 1
```

## Results

| Name           |   AlbumCount |
|----------------|--------------|
| Aaron Goldberg |            1 |

## Explanation
The query results indicate that Aaron Goldberg is the artist who contributed to the second least number of albums, with a total of just one album.
