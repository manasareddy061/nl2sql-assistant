SELECT * FROM Invoice
