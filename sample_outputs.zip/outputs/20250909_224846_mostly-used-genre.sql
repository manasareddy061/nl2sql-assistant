SELECT Genre.Name, COUNT(Track.GenreId) AS TrackCount 
FROM Genre 
LEFT JOIN Track ON Genre.GenreId = Track.GenreId 
GROUP BY Genre.GenreId 
ORDER BY TrackCount DESC 
LIMIT 1
