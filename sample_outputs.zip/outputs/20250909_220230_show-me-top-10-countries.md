# Query: SHOW ME TOP 10 COUNTRIES

## SQL

```sql
SELECT Customer.Country, SUM(Invoice.Total) AS Revenue 
FROM Invoice 
JOIN Customer ON Invoice.CustomerId = Customer.CustomerId 
GROUP BY Customer.Country 
ORDER BY Revenue DESC 
LIMIT 10
```

## Results

| Country        |   Revenue |
|----------------|-----------|
| USA            |    523.06 |
| Canada         |    303.96 |
| France         |    195.1  |
| Brazil         |    190.1  |
| Germany        |    156.48 |
| United Kingdom |    112.86 |
| Czech Republic |     90.24 |
| Portugal       |     77.24 |
| India          |     75.26 |
| Chile          |     46.62 |

## Explanation
The query results show the top 10 countries by revenue generated from invoices, with the USA leading at $523.06, followed by Canada at $303.96 and France at $195.10. This indicates strong sales performance in these regions.
