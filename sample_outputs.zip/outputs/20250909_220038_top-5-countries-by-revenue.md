# Query: Top 5 countries by revenue

## SQL

```sql
SELECT Customer.Country, SUM(Invoice.Total) AS Revenue 
FROM Invoice 
JOIN Customer ON Invoice.CustomerId = Customer.CustomerId 
GROUP BY Customer.Country 
ORDER BY Revenue DESC 
LIMIT 5
```

## Results

| Country   |   Revenue |
|-----------|-----------|
| USA       |    523.06 |
| Canada    |    303.96 |
| France    |    195.1  |
| Brazil    |    190.1  |
| Germany   |    156.48 |

## Explanation
The top five countries by revenue are the USA with $523.06, followed by Canada at $303.96, France at $195.10, Brazil at $190.10, and Germany at $156.48. This indicates that the USA is the leading market, significantly outperforming the others.
