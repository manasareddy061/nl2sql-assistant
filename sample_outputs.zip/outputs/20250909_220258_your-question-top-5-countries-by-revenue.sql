SELECT Customer.Country, SUM(Invoice.Total) AS Revenue FROM Invoice JOIN Customer ON Invoice.CustomerId = Customer.CustomerId GROUP BY Customer.Country ORDER BY Revenue DESC LIMIT 5
