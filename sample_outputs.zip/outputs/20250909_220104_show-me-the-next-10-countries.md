# Query: Show me the next 10 countries

## SQL

```sql
SELECT Customer.Country, SUM(Invoice.Total) AS Revenue 
FROM Invoice 
JOIN Customer ON Invoice.CustomerId = Customer.CustomerId 
GROUP BY Customer.Country 
ORDER BY Revenue DESC 
LIMIT 5 OFFSET 5
```

## Results

| Country        |   Revenue |
|----------------|-----------|
| United Kingdom |    112.86 |
| Czech Republic |     90.24 |
| Portugal       |     77.24 |
| India          |     75.26 |
| Chile          |     46.62 |

## Explanation
The next five countries by revenue after the top five are the United Kingdom, Czech Republic, Portugal, India, and Chile, with revenues ranging from approximately $46.62 to $112.86.
