# Query: Which artist contributed to the less albums?

## SQL

```sql
SELECT Artist.Name, COUNT(Album.AlbumId) AS AlbumCount 
FROM Artist 
LEFT JOIN Album ON Artist.ArtistId = Album.ArtistId 
GROUP BY Artist.ArtistId 
ORDER BY AlbumCount ASC 
LIMIT 1
```

## Results

| Name                       |   AlbumCount |
|----------------------------|--------------|
| Milton Nascimento & Bebeto |            0 |

## Explanation
The artist "Milton Nascimento & Bebeto" has not contributed to any albums, making them the artist with the fewest album releases.
