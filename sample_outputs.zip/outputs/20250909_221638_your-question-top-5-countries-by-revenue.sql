SELECT Customer.Country, SUM(Invoice.Total) AS TotalRevenue FROM Invoice JOIN Customer ON Invoice.CustomerId = Customer.CustomerId GROUP BY Customer.Country ORDER BY TotalRevenue DESC LIMIT 5
