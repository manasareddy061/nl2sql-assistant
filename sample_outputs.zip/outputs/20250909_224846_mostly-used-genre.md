# Query: mostly used genre

## SQL

```sql
SELECT Genre.Name, COUNT(Track.GenreId) AS TrackCount 
FROM Genre 
LEFT JOIN Track ON Genre.GenreId = Track.GenreId 
GROUP BY Genre.GenreId 
ORDER BY TrackCount DESC 
LIMIT 1
```

## Results

| Name   |   TrackCount |
|--------|--------------|
| Rock   |         1297 |

## Explanation
The most popular music genre is Rock, with a total of 1,297 tracks available.
