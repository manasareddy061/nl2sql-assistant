SELECT Artist.Name, COUNT(Album.AlbumId) AS AlbumCount FROM Album JOIN Artist ON Album.ArtistId = Artist.ArtistId GROUP BY Artist.Name ORDER BY AlbumCount ASC LIMIT 1
