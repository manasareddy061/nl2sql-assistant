# Query: Your question: Top 5 countries by revenue

## SQL

```sql
SELECT Customer.Country, SUM(Invoice.Total) AS TotalRevenue FROM Invoice JOIN Customer ON Invoice.CustomerId = Customer.CustomerId GROUP BY Customer.Country ORDER BY TotalRevenue DESC LIMIT 5
```

## Results

| Country   |   TotalRevenue |
|-----------|----------------|
| USA       |         523.06 |
| Canada    |         303.96 |
| France    |         195.1  |
| Brazil    |         190.1  |
| Germany   |         156.48 |

## Explanation
The top five countries by revenue are the USA, Canada, France, Brazil, and Germany, with the USA generating the highest revenue at $523.06. This indicates strong sales performance in these regions.
