SELECT Artist.Name, COUNT(Album.AlbumId) AS AlbumCount 
FROM Artist 
JOIN Album ON Artist.ArtistId = Album.ArtistId 
GROUP BY Artist.ArtistId 
ORDER BY AlbumCount DESC 
LIMIT 1
