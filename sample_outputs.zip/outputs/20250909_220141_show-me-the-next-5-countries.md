# Query: Show me the next 5 countries

## SQL

```sql
SELECT Customer.Country, SUM(Invoice.Total) AS Revenue 
FROM Invoice 
JOIN Customer ON Invoice.CustomerId = Customer.CustomerId 
GROUP BY Customer.Country 
ORDER BY Revenue DESC 
LIMIT 5 OFFSET 10
```

## Results

| Country     |   Revenue |
|-------------|-----------|
| Ireland     |     45.62 |
| Hungary     |     45.62 |
| Austria     |     42.62 |
| Finland     |     41.62 |
| Netherlands |     40.62 |

## Explanation
The next five countries by revenue are Ireland and Hungary, both with $45.62, followed by Austria at $42.62, Finland at $41.62, and the Netherlands at $40.62.
