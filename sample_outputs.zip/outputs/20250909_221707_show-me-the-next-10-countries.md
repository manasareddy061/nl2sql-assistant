# Query: Show me the next 10 countries

## SQL

```sql
SELECT Customer.Country, SUM(Invoice.Total) AS TotalRevenue FROM Invoice JOIN Customer ON Invoice.CustomerId = Customer.CustomerId GROUP BY Customer.Country ORDER BY TotalRevenue DESC LIMIT 10 OFFSET 5
```

## Results

| Country        |   TotalRevenue |
|----------------|----------------|
| United Kingdom |         112.86 |
| Czech Republic |          90.24 |
| Portugal       |          77.24 |
| India          |          75.26 |
| Chile          |          46.62 |
| Ireland        |          45.62 |
| Hungary        |          45.62 |
| Austria        |          42.62 |
| Finland        |          41.62 |
| Netherlands    |          40.62 |

## Explanation
The query results show the next five countries by total revenue after the top five, with the United Kingdom leading at $112.86, followed by the Czech Republic, Portugal, India, and Chile. These figures indicate the revenue generated from invoices in these countries.
