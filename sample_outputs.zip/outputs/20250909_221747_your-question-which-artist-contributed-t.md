# Query: Your question: Which artist contributed to the most albums?

## SQL

```sql
SELECT Artist.Name, COUNT(Album.AlbumId) AS AlbumCount FROM Album JOIN Artist ON Album.ArtistId = Artist.ArtistId GROUP BY Artist.Name ORDER BY AlbumCount DESC LIMIT 1
```

## Results

| Name        |   AlbumCount |
|-------------|--------------|
| Iron Maiden |           21 |

## Explanation
The artist that contributed to the most albums is Iron Maiden, with a total of 21 albums.
