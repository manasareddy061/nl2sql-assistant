# Query: mostly used genre

## SQL

```sql
SELECT Genre.Name, COUNT(Track.GenreId) AS TrackCount FROM Track JOIN Genre ON Track.GenreId = Genre.GenreId GROUP BY Genre.Name ORDER BY TrackCount DESC LIMIT 1
```

## Results

| Name   |   TrackCount |
|--------|--------------|
| Rock   |         1297 |

## Explanation
The most popular music genre is Rock, with a total of 1,297 tracks available.
