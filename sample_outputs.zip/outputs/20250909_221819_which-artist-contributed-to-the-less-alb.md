# Query: Which artist contributed to the less albums?

## SQL

```sql
SELECT Artist.Name, COUNT(Album.AlbumId) AS AlbumCount FROM Album JOIN Artist ON Album.ArtistId = Artist.ArtistId GROUP BY Artist.Name ORDER BY AlbumCount ASC LIMIT 1
```

## Results

| Name                                      |   AlbumCount |
|-------------------------------------------|--------------|
| Aaron Copland & London Symphony Orchestra |            1 |

## Explanation
The artist who contributed to the fewest albums is "Aaron Copland & London Symphony Orchestra," with only 1 album released.
